from django.contrib import admin
from django.urls import path, include
from .views import *
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', index, name="index"),

    path('mypage', mypage, name="mypage"),
    path('predict', predict, name="predict"),
    path('mypage', mypage, name="mypage"),
    path('update_user', update_user, name="update_user"),
    path('addScore', addScore, name="addScore"),

    path('startStudy', startStudy, name="startStudy"),
    path('stopStudy', stopStudy, name="stopStudy"),

    path('login', login_request, name="login_request"),
    path('logout', logout_request, name="logout_request"),
    path('signup', signup, name="signup"), # 회원가입 화면
    path('signup-submit',doSignup, name='doSignup'), # 회원가입
    path('signup-username',check_duplication_username, name='check_duplication_username'), # 아이디 중복 체크


] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
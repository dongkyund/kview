from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import *
from .forms import *
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.hashers import make_password
from django.http import HttpResponse
import json
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q
from django.core.mail.message import EmailMessage
from django.core.mail import send_mail
import datetime
import random
import string
from datetime import date, timedelta
from datetime import datetime as dt
from django.db.models import Count, Avg
from django.utils import timezone
from django.utils import dateparse
from django.contrib.auth.decorators import login_required


# HOME
@login_required(login_url='/login')
def index(request):
    yet = True
    now_percent = 0
    now_time = 0
    less_or_more = "같아요"
    less_or_more_time = 0
    if request.user.is_authenticated:
        if request.user.today_status == True:
            yet = False
        # 오늘 공부시간 달성 퍼센트
        if request.user.start_date != None:
            if request.user.today_status:
                if request.user.today_total_time != None:
                    now_percent = round(100* request.user.today_total_time / request.user.goal_time) + round(100 * ((timezone.now() - request.user.today_start_time).seconds / 3600)/request.user.goal_time)
                    now_time = request.user.today_total_time + round((timezone.now() - request.user.today_start_time).seconds / 3600)
                else:
                    now_percent = round(100 * ((timezone.now() - request.user.today_start_time).seconds / 3600)/request.user.goal_time)
                    now_time = round((timezone.now() - request.user.today_start_time).seconds / 3600)

            elif request.user.today_total_time is not None:
                now_percent = round(100* request.user.today_total_time / request.user.goal_time)
                now_time = request.user.today_total_time

        # 합격률 예측 = 같은 시험을 본 사람 중,
        # 나보다 점수 같거나 낮은 사람이 합격한 수 / 전체 합격자 수

        # 전체합격자 수
        all_pass_count = len(User.objects.filter(cos=request.user.cos).filter(status="합격"))

        # 나보다 점수 같거나 낮은 사람이 합격한 수
        my_pass_count = 0
        pass_percent = 0
        pass_average_time = 0
        if len(User.objects.filter(cos=request.user.cos).filter(status="합격")) > 0 :
            my_pass_count = len(User.objects.filter(cos=request.user.cos).filter(status="합격").filter(average_score__lte=request.user.average_score))
            print(my_pass_count)
            # 합격자 평균보다 적거나 많은 시간
            pass_average_time = round(User.objects.filter(cos=request.user.cos).filter(status="합격").aggregate(Avg('average_time'))['average_time__avg'])
            less_or_more_time = pass_average_time - request.user.average_time
        if all_pass_count > 0:
            pass_percent = round(my_pass_count/all_pass_count*100)
        else:
            pass_percent = 0
        recent_score = 0
        if len(Score.objects.filter(user=request.user)) > 0:
            recent_score = Score.objects.filter(user=request.user).order_by('-score_date')[0].score
        
        
        if less_or_more_time > 0:
            less_or_more = "적어요"
        elif less_or_more_time < 0:
            less_or_more = "많아요"
            less_or_more_time = -less_or_more_time

        six_percent = 0
        seven_percent = 0
        eight_percent = 0
        nine_percent = 0
        ten_percent = 0
        eleven_percent = 0

        # 공부시간 합격률
        if len(User.objects.filter(cos=request.user.cos).filter(average_time=6)) > 0:
            six_percent = round(100*len(User.objects.filter(cos=request.user.cos).filter(average_time=6).filter(status="합격"))/len(User.objects.filter(cos=request.user.cos).filter(average_time=6)))
        if len(User.objects.filter(cos=request.user.cos).filter(average_time=7)) > 0:
            seven_percent = round(100*len(User.objects.filter(cos=request.user.cos).filter(average_time=7).filter(status="합격"))/len(User.objects.filter(cos=request.user.cos).filter(average_time=7)))
        if len(User.objects.filter(cos=request.user.cos).filter(average_time=8)) > 0:
            eight_percent = round(100*len(User.objects.filter(cos=request.user.cos).filter(average_time=8).filter(status="합격"))/len(User.objects.filter(cos=request.user.cos).filter(average_time=8)))
        if len(User.objects.filter(cos=request.user.cos).filter(average_time=9)) > 0:
            nine_percent = round(100*len(User.objects.filter(cos=request.user.cos).filter(average_time=9).filter(status="합격"))/len(User.objects.filter(cos=request.user.cos).filter(average_time=9)))
        if len(User.objects.filter(cos=request.user.cos).filter(average_time=10)) > 0:
            ten_percent = round(100*len(User.objects.filter(cos=request.user.cos).filter(average_time=10).filter(status="합격"))/len(User.objects.filter(cos=request.user.cos).filter(average_time=10)))
        if len(User.objects.filter(cos=request.user.cos).filter(average_time=11)) > 0:
            eleven_percent = round(100*len(User.objects.filter(cos=request.user.cos).filter(average_time=11).filter(status="합격"))/len(User.objects.filter(cos=request.user.cos).filter(average_time=11)))
        
    return render(request,'index.html',{'yet':yet,'now_percent':now_percent,'pass_percent':pass_percent,'recent_score':recent_score,
    'now_time':now_time,'less_or_more':less_or_more,'less_or_more_time':less_or_more_time,'pass_average_time':pass_average_time,
    'six_percent':six_percent,'seven_percent':seven_percent,'eight_percent':eight_percent,'nine_percent':nine_percent,
    'ten_percent':ten_percent,'eleven_percent':eleven_percent})

# 로그인
def login_request(request):
    form = LoginForm(request.POST or None)
    msg = None
    if request.method == "POST":
        if form.is_valid():
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password")
            user = authenticate(username=username, password=password)
            if user is not None:
                print("non user")
                login(request, user)
                return redirect("index")
            else:
                msg = '아이디 또는 비밀번호를 다시 확인해주세요.'
        else:
            msg = 'Error validating the form'
    return render(request, 'login.html', {'form': form, 'msg': msg})


# 로그아웃
def logout_request(request):
    logout(request)
    return redirect("login_request")

# 회원가입 - 화면
def signup(request):
    yet = True
    if request.user.is_authenticated:
        if request.user.today_status == True:
            yet = False
    return render(request, "signup.html",{'yet':yet})

# 회원가입
def doSignup(request):
    if request.method == "POST":
        users = User.objects.filter(username=request.POST['username'])
        username = request.POST['username']
        if len(username) < 6:
            message='usernameFail'
            return HttpResponse(json.dumps({'message':message}), content_type="application/json")
        password1 = request.POST['password1']
        name = request.POST['name']
        goal = request.POST['goal']
        goal_time = request.POST['goal_time']
        start_date = request.POST['start_date']
        cos = request.POST['cos']
        User(
            username=username,
            password=make_password(password1),
            name=name,
            goal=goal,
            goal_time=goal_time,
            start_date=start_date,
            cos=cos,
            average_time=0,
            total_time=0,
            status='진행중',
            average_score = 0,
            time_count = 0
        ).save()
        message = 'success'
        return HttpResponse(json.dumps({'message':message}), content_type="application/json")

# 아이디 중복확인
def check_duplication_username(request):
    if request.method == "POST":
        username = request.POST['username']
        users = User.objects.filter(username=username)
        if len(users) > 0:
            message='이미 사용중인 아이디입니다.'
            status='fail'
        else:
            message='사용 가능한 아이디입니다.'
            status='success'
        return HttpResponse(json.dumps({'message':message,'status':status}), content_type="application/json")

# 마이페이지
def mypage(request):
    yet = True
    if request.user.is_authenticated:
        if request.user.today_status == True:
            yet = False
    scores = Score.objects.filter(user=request.user)
    user = request.user
    return render(request,'mypage.html',{'scores':scores,'user':user,'yet':yet})

# 점수추가
def addScore(request):
    if request.method == "POST":
        score = request.POST['score']

        Score(user=request.user,score_date=datetime.date.today(),score=score).save()
        user = request.user
        scores = Score.objects.filter(user=user)
        total_score = 0
        for score in scores:
            total_score += score.score
        user.average_score = total_score/len(scores)
        user.save()

        message = 'success'
        return HttpResponse(json.dumps({'message':message}), content_type="application/json")

# START STUDY
def startStudy(request):
    if request.method == "POST":
        user=request.user
        user.today_status = True
        if user.today_start_time == None:
            user.today_start_time = timezone.now()
            user.today_total_time = 0
        user.save()

        message = 'success'
        return HttpResponse(json.dumps({'message':message}), content_type="application/json")

# STOP STUDY
def stopStudy(request):
    if request.method == "POST":
        user=request.user
        user.today_status = False
        time = timezone.now()
        if user.today_total_time != None:
            today_total_time = round((time - user.today_start_time).seconds / 3600) + user.today_total_time
            user.average_time = (user.average_time * user.time_count - user.average_time + today_total_time )/(user.time_count)
        else:
            today_total_time = round((time - user.today_start_time).seconds / 3600)
            user.average_time = (user.average_time * user.time_count + today_total_time)/(user.time_count+1)
            user.time_count = user.time_count + 1
        user.today_total_time = today_total_time
        user.total_time = user.total_time + today_total_time
        user.today_start_time = None
        user.save()

        message = 'success'
        return HttpResponse(json.dumps({'message':message}), content_type="application/json")

# 회원 수정
def update_user(request):
    if request.method == "POST":
        name = request.POST['name']
        goal = request.POST['goal']
        goal_time = request.POST['goal_time']
        start_date = request.POST['start_date']
        cos = request.POST['cos']
        status = request.POST['status']

        user = request.user
        user.name = name
        user.goal = goal
        user.goal_time = goal_time
        user.start_date = start_date
        user.cos = cos
        user.status = status

        user.save()
        message = 'success'
        return HttpResponse(json.dumps({'message':message}), content_type="application/json")


# 합격 예측진단
def predict(request):
    less_or_plus = ''

    pass_percent = round(100 * len(User.objects.filter(status="합격").filter(average_time=request.user.average_time).filter(cos=request.user.cos))/len(User.objects.filter(average_time=request.user.average_time).filter(cos=request.user.cos)))

    yet = True
    if request.user.is_authenticated:
        if request.user.today_status == True:
            yet = False
            
    if len(User.objects.filter(status="합격").filter(cos=request.user.cos)):
        my_time = round(round(User.objects.filter(status="합격").filter(cos=request.user.cos).aggregate(Avg('average_time'))['average_time__avg']) - request.user.average_time)
        average_score = round(User.objects.filter(status="합격").filter(cos=request.user.cos).aggregate(Avg('average_score'))['average_score__avg'])
        total_time = round(User.objects.filter(status="합격").filter(cos=request.user.cos).aggregate(Avg('total_time'))['total_time__avg'])
        average_time = round(User.objects.filter(status="합격").filter(cos=request.user.cos).aggregate(Avg('average_time'))['average_time__avg'])

    else:
        my_time = 0
        average_score = 0
        total_time = 0
        average_time = 0

    if my_time > 0:
        less_or_plus = '적어요'
    elif my_time < 0:
        less_or_plus = '많아요'
    else:
        less_or_plus = '같아요'

    
    print("average_score")
    print(average_score)

    
    now = str(datetime.datetime.now().year) + "년 " + str(datetime.datetime.now().month) + "월 " + str(datetime.datetime.now().day) + "일 기준"

    return render(request,'predict.html',{'pass_percent':pass_percent,'less_or_plus':less_or_plus,'my_time':my_time,'average_score':average_score,
    'total_time':total_time,'average_time':average_time,'now':now,'yet':yet})
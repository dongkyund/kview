from django.db import models
from django.contrib.auth.models import AbstractUser

# 사용자
class User(AbstractUser):
    name = models.CharField(max_length=30, verbose_name='이름',blank=True, null=True)
    goal = models.CharField(max_length=30, verbose_name='목표',blank=True, null=True)
    start_date = models.DateField(verbose_name='공부시작일',null=True)
    average_time = models.IntegerField(verbose_name='일평균 공부시간',blank=True, null=True)
    total_time = models.IntegerField(blank=True, null=True, verbose_name='TOTAL 공부시간')
    goal_time = models.IntegerField(blank=True, null=True, verbose_name='1일 목표 공부시간')
    cos = models.CharField(max_length=50,blank=True, null=True, verbose_name='코스')
    status = models.CharField(max_length=30, verbose_name='상태(진행중/합격/불합격)',blank=True, null=True)
    average_score = models.IntegerField(verbose_name='모의고사 평균점수',blank=True, null=True)
    today_status = models.BooleanField(default=False, verbose_name='공부 진행중 여부')
    today_start_time = models.DateTimeField(verbose_name='오늘 공부 시작시간',blank=True, null=True)
    today_total_time = models.IntegerField(verbose_name='오늘 공부 TOTAL 시간',blank=True, null=True)
    time_count = models.IntegerField(verbose_name='공부한날수',blank=True, null=True)

    created_at = models.DateTimeField(auto_now_add=True, null=True, verbose_name='등록일시')
    updated_at = models.DateTimeField(auto_now=True, null=True, verbose_name='수정일시')

    def __str__(self):
        return self.username
    
    class Meta:
        verbose_name_plural = "사용자"

# 점수이력
class Score(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="notice_user", verbose_name='작성자 아이디') #작성자   
    score = models.IntegerField(verbose_name='점수',blank=True, null=True)
    score_date = models.DateField(verbose_name='공부시작일',blank=True, null=True)
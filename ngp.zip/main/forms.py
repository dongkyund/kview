
from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User
import datetime

class LoginForm(forms.Form):
    username = forms.CharField(
        widget=forms.TextInput(
            attrs={
                "placeholder": "아이디를 입력해주세요.",
                "class": "form-control"
            }
        ))
    password = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                "placeholder": "비밀번호를 입력해주세요.",
                "class": "form-control"
            }
        ))